#!/usr/bin/env python3
from pathlib import Path
import json
from collections import Counter

BASE = Path.home() / "Documents/ToribashAI"
PARSED = BASE / "parsed"
META = BASE / "metadata"

OUT = META / "dataset_index.jsonl"
SUMMARY = META / "dataset_classification_summary.json"

PARKOUR_WORDS = [
    "parkour", "freerun", "free_run", "freerunning",
    "running", "runandjump", "vault", "rooftop",
    "mirror", "mirrors", "edge", "raid", "tomb",
    "climb", "climbing", "pigrun", "extremerun",
    "monkeybar", "urban", "city", "obstacle",
]

COMBAT_WORDS = [
    "aikido", "judo", "sambo", "mushu", "wushu",
    "taekkyon", "spar", "sparring", "lenshu",
    "ninjutsu", "kickbox", "katana", "sword",
    "mma", "rk-mma", "joust", "dojo", "classic",
]

TRICKING_WORDS = [
    "trick", "xtrick", "flip", "madman", "instagib",
    "footmod", "decap", "fatality",
]


def norm(text):
    return (text or "").lower().replace("\\", "/")


def classify(mod, fightname, filename):
    text = " ".join([norm(mod), norm(fightname), norm(filename)])

    parkour_score = sum(1 for w in PARKOUR_WORDS if w in text)
    combat_score = sum(1 for w in COMBAT_WORDS if w in text)
    tricking_score = sum(1 for w in TRICKING_WORDS if w in text)

    if parkour_score > 0 and parkour_score >= combat_score:
        return "parkour_candidate"

    if combat_score > 0:
        return "combat"

    if tricking_score > 0:
        return "classic_tricking"

    return "unknown"


def main():
    META.mkdir(parents=True, exist_ok=True)

    counts = Counter()
    frames_by_label = Counter()
    mods_by_label = {}

    files = sorted(PARSED.glob("*.json"))

    with OUT.open("w", encoding="utf-8") as out:
        for path in files:
            data = json.loads(path.read_text(encoding="utf-8"))

            metadata = data.get("metadata", {})
            mod = metadata.get("mod", "UNKNOWN")
            fightname = metadata.get("fightname", "")
            frames = len(data.get("frames", {}))

            label = classify(mod, fightname, path.stem)

            counts[label] += 1
            frames_by_label[label] += frames
            mods_by_label.setdefault(label, Counter())[mod] += 1

            row = {
                "json_path": str(path),
                "rpl_path": data.get("file"),
                "filename": path.stem,
                "label": label,
                "mod": mod,
                "fightname": fightname,
                "frames": frames,
                "authors": metadata.get("authors", {}),
                "players": metadata.get("players", {}),
            }

            out.write(json.dumps(row, ensure_ascii=False) + "\n")

    summary = {
        "total": sum(counts.values()),
        "counts": dict(counts),
        "frames_by_label": dict(frames_by_label),
        "top_mods_by_label": {
            label: counter.most_common(30)
            for label, counter in mods_by_label.items()
        },
    }

    SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("Index écrit:", OUT)
    print("Résumé écrit:", SUMMARY)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
