#!/usr/bin/env python3
from pathlib import Path
import json
from collections import Counter, defaultdict
import math

BASE = Path.home() / "Documents/ToribashAI"
DATASET = BASE / "datasets" / "ml" / "parkour_transitions.jsonl"
OUT = BASE / "datasets" / "ml" / "parkour_dataset_check.json"

EXPECTED_STATE_DIM = 273
EXPECTED_ACTION_DIM = 20


def is_finite_list(values):
    return all(isinstance(v, (int, float)) and math.isfinite(v) for v in values)


def main():
    total = 0
    bad_state_dim = 0
    bad_action_dim = 0
    bad_next_state_dim = 0
    non_finite = 0

    dt_counter = Counter()
    action_values = Counter()
    action_by_joint = defaultdict(Counter)
    mod_counter = Counter()

    min_dt = None
    max_dt = None

    examples_bad = []

    with DATASET.open("r", encoding="utf-8") as f:
        for line_number, line in enumerate(f, start=1):
            row = json.loads(line)
            total += 1

            state = row.get("state", [])
            action = row.get("action", [])
            next_state = row.get("next_state", [])
            dt = row.get("dt_frames")
            mod = row.get("mod", "UNKNOWN")

            mod_counter[mod] += 1
            dt_counter[dt] += 1

            if min_dt is None or dt < min_dt:
                min_dt = dt
            if max_dt is None or dt > max_dt:
                max_dt = dt

            if len(state) != EXPECTED_STATE_DIM:
                bad_state_dim += 1
                examples_bad.append({
                    "line": line_number,
                    "problem": "bad_state_dim",
                    "dim": len(state),
                    "file": row.get("source_json"),
                })

            if len(next_state) != EXPECTED_STATE_DIM:
                bad_next_state_dim += 1
                examples_bad.append({
                    "line": line_number,
                    "problem": "bad_next_state_dim",
                    "dim": len(next_state),
                    "file": row.get("source_json"),
                })

            if len(action) != EXPECTED_ACTION_DIM:
                bad_action_dim += 1
                examples_bad.append({
                    "line": line_number,
                    "problem": "bad_action_dim",
                    "dim": len(action),
                    "file": row.get("source_json"),
                })

            if not is_finite_list(state) or not is_finite_list(next_state):
                non_finite += 1
                examples_bad.append({
                    "line": line_number,
                    "problem": "non_finite",
                    "file": row.get("source_json"),
                })

            for joint_id, value in enumerate(action):
                action_values[value] += 1
                action_by_joint[str(joint_id)][value] += 1

    summary = {
        "dataset": str(DATASET),
        "total_transitions": total,
        "expected_state_dim": EXPECTED_STATE_DIM,
        "expected_action_dim": EXPECTED_ACTION_DIM,
        "bad_state_dim": bad_state_dim,
        "bad_next_state_dim": bad_next_state_dim,
        "bad_action_dim": bad_action_dim,
        "non_finite": non_finite,
        "dt_frames": {
            "min": min_dt,
            "max": max_dt,
            "distribution_top": dt_counter.most_common(20),
        },
        "action_values_total": action_values.most_common(),
        "action_values_by_joint": {
            joint: counter.most_common()
            for joint, counter in action_by_joint.items()
        },
        "top_mods": mod_counter.most_common(30),
        "examples_bad": examples_bad[:30],
    }

    OUT.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("Check écrit:", OUT)
    print("Transitions:", total)
    print("Bad state dim:", bad_state_dim)
    print("Bad next state dim:", bad_next_state_dim)
    print("Bad action dim:", bad_action_dim)
    print("Non finite:", non_finite)
    print("dt min/max:", min_dt, max_dt)
    print("Actions observées:", action_values.most_common())


if __name__ == "__main__":
    main()
