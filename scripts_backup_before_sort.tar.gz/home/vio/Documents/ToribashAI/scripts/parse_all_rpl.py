#!/usr/bin/env python3
from pathlib import Path
import json
import time
import traceback

from parse_rpl import parse_rpl

BASE = Path.home() / "Documents/ToribashAI"

RPL_DIR = BASE / "replays_raw" / "parkour_candidate"
PARSED_DIR = BASE / "parsed"
META_DIR = BASE / "metadata"

LOG_JSONL = META_DIR / "parse_all_rpl_log.jsonl"
ERROR_LOG = META_DIR / "parse_errors.txt"
SUMMARY_JSON = META_DIR / "parse_summary.json"

SKIP_EXISTING = True

PARSED_DIR.mkdir(parents=True, exist_ok=True)
META_DIR.mkdir(parents=True, exist_ok=True)


def save_json(path, data):
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )


def log_jsonl(data):
    with LOG_JSONL.open("a", encoding="utf-8") as f:
        f.write(json.dumps(data, ensure_ascii=False) + "\n")


def count_frames(parsed):
    return len(parsed.get("frames", {}))


def get_players(parsed):
    players = parsed.get("metadata", {}).get("players", {})
    return sorted(players.keys())


def main():
    files = sorted(RPL_DIR.glob("*.rpl"))

    total = len(files)
    parsed_count = 0
    skipped_count = 0
    error_count = 0

    total_frames = 0
    mods = {}
    authors = {}

    print("Dossier RPL:", RPL_DIR)
    print("Replays trouvés:", total)
    print("Sortie JSON:", PARSED_DIR)
    print("Skip existing:", SKIP_EXISTING)

    start = time.time()

    for i, rpl_path in enumerate(files, start=1):
        out_path = PARSED_DIR / (rpl_path.stem + ".json")

        if SKIP_EXISTING and out_path.exists():
            skipped_count += 1
            print(f"[{i}/{total}] skip déjà parsé: {rpl_path.name}")
            continue

        print(f"[{i}/{total}] parse: {rpl_path.name}")

        try:
            parsed = parse_rpl(rpl_path)
            save_json(out_path, parsed)

            metadata = parsed.get("metadata", {})
            frame_count = count_frames(parsed)
            mod = metadata.get("mod", "UNKNOWN")

            total_frames += frame_count
            mods[mod] = mods.get(mod, 0) + 1

            for _, author_name in metadata.get("authors", {}).items():
                authors[author_name] = authors.get(author_name, 0) + 1

            parsed_count += 1

            log_jsonl({
                "status": "ok",
                "rpl": str(rpl_path),
                "json": str(out_path),
                "frames": frame_count,
                "mod": mod,
                "players": get_players(parsed),
            })

        except Exception as e:
            error_count += 1
            print("  ERREUR:", e)

            with ERROR_LOG.open("a", encoding="utf-8") as f:
                f.write(f"\n--- ERROR {rpl_path} ---\n")
                f.write(traceback.format_exc())

            log_jsonl({
                "status": "error",
                "rpl": str(rpl_path),
                "error": str(e),
            })

    elapsed = time.time() - start

    summary = {
        "rpl_dir": str(RPL_DIR),
        "parsed_dir": str(PARSED_DIR),
        "total_rpl_found": total,
        "parsed_this_run": parsed_count,
        "skipped_existing": skipped_count,
        "errors": error_count,
        "total_frames_this_run": total_frames,
        "average_frames_this_run": (
            total_frames / parsed_count if parsed_count else 0
        ),
        "unique_mods_this_run": len(mods),
        "top_mods_this_run": sorted(
            mods.items(),
            key=lambda x: x[1],
            reverse=True
        )[:30],
        "unique_authors_this_run": len(authors),
        "top_authors_this_run": sorted(
            authors.items(),
            key=lambda x: x[1],
            reverse=True
        )[:30],
        "elapsed_seconds": round(elapsed, 2),
    }

    save_json(SUMMARY_JSON, summary)

    print("\nTerminé.")
    print("Parsés cette session:", parsed_count)
    print("Déjà existants skip:", skipped_count)
    print("Erreurs:", error_count)
    print("Frames cette session:", total_frames)
    print("Résumé:", SUMMARY_JSON)
    print("Log:", LOG_JSONL)
    print("Erreurs log:", ERROR_LOG)


if __name__ == "__main__":
    main()
