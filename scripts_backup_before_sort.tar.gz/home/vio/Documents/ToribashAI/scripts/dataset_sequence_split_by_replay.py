#!/usr/bin/env python3
from pathlib import Path
import json
import random
from collections import defaultdict

BASE = Path.home() / "Documents/ToribashAI"

IN_DATASET = BASE / "datasets" / "ml" / "parkour_sequences_len8.jsonl"
OUT_DIR = BASE / "datasets" / "ml"

TRAIN_OUT = OUT_DIR / "parkour_sequences_len8_train_by_replay.jsonl"
VAL_OUT = OUT_DIR / "parkour_sequences_len8_val_by_replay.jsonl"
SUMMARY = OUT_DIR / "parkour_sequences_len8_replay_split_summary.json"

TRAIN_RATIO = 0.9
SEED = 42

random.seed(SEED)


def main():
    rows_by_replay = defaultdict(list)

    with IN_DATASET.open("r", encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            rows_by_replay[row["source_json"]].append(row)

    replays = sorted(rows_by_replay.keys())
    random.shuffle(replays)

    train_count = int(len(replays) * TRAIN_RATIO)

    train_replays = set(replays[:train_count])
    val_replays = set(replays[train_count:])

    train_sequences = 0
    val_sequences = 0

    with TRAIN_OUT.open("w", encoding="utf-8") as train_f, \
         VAL_OUT.open("w", encoding="utf-8") as val_f:

        for replay in replays:
            target = train_f if replay in train_replays else val_f

            for row in rows_by_replay[replay]:
                target.write(json.dumps(row, ensure_ascii=False) + "\n")

                if replay in train_replays:
                    train_sequences += 1
                else:
                    val_sequences += 1

    summary = {
        "input": str(IN_DATASET),
        "train_output": str(TRAIN_OUT),
        "val_output": str(VAL_OUT),
        "seed": SEED,
        "train_ratio": TRAIN_RATIO,
        "total_replays": len(replays),
        "train_replays": len(train_replays),
        "val_replays": len(val_replays),
        "train_sequences": train_sequences,
        "val_sequences": val_sequences,
    }

    SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("Train:", TRAIN_OUT)
    print("Val:", VAL_OUT)
    print("Résumé:", SUMMARY)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
