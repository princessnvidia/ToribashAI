#!/usr/bin/env python3
from pathlib import Path
import json
from collections import Counter

BASE = Path.home() / "Documents/ToribashAI"

IN_DATASET = BASE / "datasets" / "ml" / "parkour_transitions.jsonl"
OUT_DATASET = BASE / "datasets" / "ml" / "parkour_transitions_clean.jsonl"
SUMMARY = BASE / "datasets" / "ml" / "parkour_transitions_clean_summary.json"

MAX_DT_FRAMES = 40
EXPECTED_STATE_DIM = 273
EXPECTED_ACTION_DIM = 20


def is_valid(row):
    if row.get("dt_frames", 999999) > MAX_DT_FRAMES:
        return False

    if len(row.get("state", [])) != EXPECTED_STATE_DIM:
        return False

    if len(row.get("next_state", [])) != EXPECTED_STATE_DIM:
        return False

    if len(row.get("action", [])) != EXPECTED_ACTION_DIM:
        return False

    return True


def main():
    total = 0
    kept = 0
    rejected = 0

    dt_all = Counter()
    dt_kept = Counter()
    action_values = Counter()
    mods = Counter()

    with IN_DATASET.open("r", encoding="utf-8") as fin, \
         OUT_DATASET.open("w", encoding="utf-8") as fout:

        for line in fin:
            row = json.loads(line)
            total += 1

            dt = row.get("dt_frames")
            dt_all[dt] += 1

            if not is_valid(row):
                rejected += 1
                continue

            fout.write(json.dumps(row, ensure_ascii=False) + "\n")

            kept += 1
            dt_kept[dt] += 1
            mods[row.get("mod", "UNKNOWN")] += 1

            for value in row.get("action", []):
                action_values[value] += 1

    summary = {
        "input": str(IN_DATASET),
        "output": str(OUT_DATASET),
        "total": total,
        "kept": kept,
        "rejected": rejected,
        "max_dt_frames": MAX_DT_FRAMES,
        "expected_state_dim": EXPECTED_STATE_DIM,
        "expected_action_dim": EXPECTED_ACTION_DIM,
        "dt_all_top": dt_all.most_common(30),
        "dt_kept_top": dt_kept.most_common(30),
        "action_values": action_values.most_common(),
        "top_mods": mods.most_common(30),
    }

    SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("Dataset clean:", OUT_DATASET)
    print("Résumé:", SUMMARY)
    print("Total:", total)
    print("Gardé:", kept)
    print("Rejeté:", rejected)


if __name__ == "__main__":
    main()
