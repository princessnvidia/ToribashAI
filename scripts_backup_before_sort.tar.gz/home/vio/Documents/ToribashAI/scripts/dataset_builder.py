#!/usr/bin/env python3
from pathlib import Path
import json
import math

BASE = Path.home() / "Documents/ToribashAI"

PARKOUR_DIR = BASE / "datasets" / "parkour_json"
DATASET_DIR = BASE / "datasets" / "ml"
OUT = DATASET_DIR / "parkour_transitions.jsonl"
SUMMARY = DATASET_DIR / "parkour_transitions_summary.json"

PLAYER_ID = "0"


def flatten(values):
    out = []
    for item in values:
        if isinstance(item, list):
            out.extend(flatten(item))
        else:
            out.append(item)
    return out


def joint_vector(player):
    joints = player.get("joints", {})
    return [joints.get(str(i), 0) for i in range(20)]


def state_vector(player):
    pos = flatten(player.get("pos", []))        # 21 * 3 = 63
    qat = flatten(player.get("qat", []))        # 21 * 4 = 84
    linvel = flatten(player.get("linvel", []))  # 21 * 3 = 63
    angvel = flatten(player.get("angvel", []))  # 21 * 3 = 63

    return pos + qat + linvel + angvel


def get_player_frame(data, frame_id):
    frame = data["frames"].get(str(frame_id), {})
    return frame.get("players", {}).get(PLAYER_ID)


def valid_player(player):
    if not player:
        return False

    return (
        len(player.get("pos", [])) == 21
        and len(player.get("qat", [])) == 21
        and len(player.get("linvel", [])) == 21
        and len(player.get("angvel", [])) == 21
        and len(player.get("joints", {})) > 0
    )


def build_from_replay(path, out_file):
    data = json.loads(path.read_text(encoding="utf-8"))
    metadata = data.get("metadata", {})
    frames = data.get("frames", {})

    frame_ids = sorted(int(k) for k in frames.keys())

    transitions = 0
    skipped = 0

    for i in range(len(frame_ids) - 1):
        t = frame_ids[i]
        t_next = frame_ids[i + 1]

        player_t = get_player_frame(data, t)
        player_next = get_player_frame(data, t_next)

        if not valid_player(player_t) or not valid_player(player_next):
            skipped += 1
            continue

        state_t = state_vector(player_t)
        action_t = joint_vector(player_t)
        state_next = state_vector(player_next)

        row = {
            "source_json": str(path),
            "source_rpl": data.get("file"),
            "fightname": metadata.get("fightname", ""),
            "mod": metadata.get("mod", ""),
            "player_id": PLAYER_ID,
            "frame": t,
            "next_frame": t_next,
            "dt_frames": t_next - t,
            "state": state_t,
            "action": action_t,
            "next_state": state_next,
        }

        out_file.write(json.dumps(row, ensure_ascii=False) + "\n")
        transitions += 1

    return {
        "file": path.name,
        "frames": len(frame_ids),
        "transitions": transitions,
        "skipped": skipped,
        "mod": metadata.get("mod", ""),
        "fightname": metadata.get("fightname", ""),
    }


def main():
    DATASET_DIR.mkdir(parents=True, exist_ok=True)

    files = sorted(PARKOUR_DIR.glob("*.json"))

    replay_summaries = []
    total_transitions = 0
    total_skipped = 0

    with OUT.open("w", encoding="utf-8") as out_file:
        for i, path in enumerate(files, start=1):
            print(f"[{i}/{len(files)}] {path.name}")

            summary = build_from_replay(path, out_file)
            replay_summaries.append(summary)

            total_transitions += summary["transitions"]
            total_skipped += summary["skipped"]

    dataset_summary = {
        "input_replays": len(files),
        "player_id": PLAYER_ID,
        "output": str(OUT),
        "total_transitions": total_transitions,
        "total_skipped": total_skipped,
        "state_dim": 273,
        "action_dim": 20,
        "state_layout": {
            "pos": "21 body parts * 3 = 63",
            "qat": "21 body parts * 4 = 84",
            "linvel": "21 body parts * 3 = 63",
            "angvel": "21 body parts * 3 = 63"
        },
        "action_layout": {
            "joints": "20 joint states"
        },
        "top_transition_replays": sorted(
            replay_summaries,
            key=lambda r: r["transitions"],
            reverse=True
        )[:30],
    }

    SUMMARY.write_text(
        json.dumps(dataset_summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("\nTerminé.")
    print("Dataset:", OUT)
    print("Résumé:", SUMMARY)
    print("Transitions:", total_transitions)
    print("State dim:", dataset_summary["state_dim"])
    print("Action dim:", dataset_summary["action_dim"])


if __name__ == "__main__":
    main()
