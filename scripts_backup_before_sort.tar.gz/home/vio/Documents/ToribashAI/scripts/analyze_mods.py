#!/usr/bin/env python3
from pathlib import Path
import json
from collections import Counter

PARSED_DIR = Path.home() / "Documents/ToribashAI" / "parsed"

mods = Counter()

files = list(PARSED_DIR.glob("*.json"))

print("JSON trouvés:", len(files))

for path in files:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        mod = data.get("metadata", {}).get("mod", "UNKNOWN")

        if not mod:
            mod = "UNKNOWN"

        mods[mod] += 1

    except Exception as e:
        print("Erreur:", path.name, e)

print("\n=== MODS ===\n")

for mod, count in mods.most_common():
    print(f"{count:5d}  {mod}")

print("\nMods uniques:", len(mods))
print("Replays total:", sum(mods.values()))
