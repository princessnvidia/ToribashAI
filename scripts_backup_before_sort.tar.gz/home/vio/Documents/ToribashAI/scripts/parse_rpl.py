#!/usr/bin/env python3
from pathlib import Path
import json
import sys


def parse_numbers(text, kind=float):
    if not text.strip():
        return []
    return [kind(x) for x in text.strip().split()]


def chunks(values, size):
    return [values[i:i + size] for i in range(0, len(values), size)]


def parse_rpl(path):
    path = Path(path)

    data = {
        "file": str(path),
        "metadata": {},
        "frames": {}
    }

    current_frame = None

    with path.open(
        "r",
        encoding="utf-8",
        errors="replace",
        newline=None
    ) as f:

        for raw_line in f:
            line = raw_line.strip()

            if not line:
                continue

            if line.startswith("#"):
                continue

            if line.startswith("VERSION "):
                data["metadata"]["version"] = line.split(" ", 1)[1]
                continue

            if line.startswith("FIGHTNAME "):
                data["metadata"]["fightname"] = (
                    line.split(";", 1)[1].strip()
                )
                continue

            if line.startswith("AUTHOR "):
                left, right = line.split(";", 1)
                player = left.split()[1]

                data["metadata"].setdefault(
                    "authors", {}
                )[player] = right.strip()

                continue

            if line.startswith("BOUT "):
                left, right = line.split(";", 1)
                player = left.split()[1]

                data["metadata"].setdefault(
                    "players", {}
                )[player] = right.strip()

                continue

            if line.startswith("NEWGAME "):
                data["metadata"]["newgame_raw"] = line

                try:
                    values = line.split(";", 1)[1].split()

                    # Les replays Toribash mettent
                    # généralement le mod à cette position
                    if len(values) >= 10:
                        data["metadata"]["mod"] = values[9]

                    else:
                        data["metadata"]["mod"] = "UNKNOWN"

                except Exception:
                    data["metadata"]["mod"] = "UNKNOWN"

                continue

            if line.startswith("FRAME "):
                before, after = line.split(";", 1)

                frame_id = int(before.split()[1])

                current_frame = frame_id

                data["frames"].setdefault(
                    str(frame_id),
                    {
                        "players": {}
                    }
                )

                data["frames"][str(frame_id)][
                    "frame_raw"
                ] = after.strip()

                continue

            if ";" not in line:
                continue

            key_part, value_part = line.split(";", 1)
            key_bits = key_part.split()

            if len(key_bits) < 2:
                continue

            record_type = key_bits[0]
            player_id = key_bits[1]

            if current_frame is None:
                current_frame = 0

                data["frames"].setdefault(
                    "0",
                    {"players": {}}
                )

            frame = data["frames"][str(current_frame)]

            player = frame["players"].setdefault(
                player_id,
                {}
            )

            if record_type == "JOINT":
                nums = parse_numbers(value_part, int)

                joint_pairs = chunks(nums, 2)

                player["joint_pairs"] = joint_pairs

                player["joints"] = {
                    str(j): state
                    for j, state in joint_pairs
                }

            elif record_type == "POS":
                nums = parse_numbers(value_part, float)

                player["pos"] = chunks(nums, 3)

            elif record_type == "QAT":
                nums = parse_numbers(value_part, float)

                player["qat"] = chunks(nums, 4)

            elif record_type == "LINVEL":
                nums = parse_numbers(value_part, float)

                player["linvel"] = chunks(nums, 3)

            elif record_type == "ANGVEL":
                nums = parse_numbers(value_part, float)

                player["angvel"] = chunks(nums, 3)

            else:
                player.setdefault(
                    "other",
                    {}
                )[record_type] = value_part.strip()

    return data


def main():
    if len(sys.argv) < 2:
        print("Usage: parse_rpl.py fichier.rpl")
        sys.exit(1)

    input_path = Path(sys.argv[1])

    output_dir = (
        Path.home()
        / "Documents"
        / "ToribashAI"
        / "parsed"
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    parsed = parse_rpl(input_path)

    output_path = (
        output_dir
        / (input_path.stem + ".json")
    )

    output_path.write_text(
        json.dumps(
            parsed,
            indent=2,
            ensure_ascii=False
        ),
        encoding="utf-8"
    )

    print("Fichier parsé:", input_path)
    print("JSON sauvé:", output_path)
    print(
        "Mod:",
        parsed["metadata"].get("mod")
    )
    print(
        "Frames:",
        len(parsed["frames"])
    )

    first_frame_key = sorted(
        parsed["frames"].keys(),
        key=int
    )[0]

    first_frame = parsed["frames"][first_frame_key]

    print("Première frame:", first_frame_key)
    print(
        "Players:",
        list(first_frame["players"].keys())
    )

    for pid, pdata in first_frame["players"].items():
        print("Player", pid)
        print(
            "  joints:",
            len(pdata.get("joints", {}))
        )
        print(
            "  pos body parts:",
            len(pdata.get("pos", []))
        )
        print(
            "  qat body parts:",
            len(pdata.get("qat", []))
        )
        print(
            "  linvel body parts:",
            len(pdata.get("linvel", []))
        )
        print(
            "  angvel body parts:",
            len(pdata.get("angvel", []))
        )


if __name__ == "__main__":
    main()
