#!/usr/bin/env python3
from pathlib import Path
import json

BASE = Path.home() / "Documents/ToribashAI"

IN_DATASET = BASE / "datasets" / "ml" / "parkour_transitions_clean.jsonl"
OUT_DATASET = BASE / "datasets" / "ml" / "parkour_sequences_len8.jsonl"
SUMMARY = BASE / "datasets" / "ml" / "parkour_sequences_len8_summary.json"

SEQ_LEN = 8
STATE_DIM = 273
ACTION_DIM = 20


def main():
    rows_by_replay = {}

    with IN_DATASET.open("r", encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)

            key = row["source_json"]
            rows_by_replay.setdefault(key, []).append(row)

    total_sequences = 0
    skipped = 0

    with OUT_DATASET.open("w", encoding="utf-8") as out:
        for source_json, rows in rows_by_replay.items():
            rows.sort(key=lambda r: r["frame"])

            for i in range(len(rows) - SEQ_LEN + 1):
                window = rows[i:i + SEQ_LEN]

                # On évite les séquences avec rupture de replay étrange
                if any(r["dt_frames"] > 40 for r in window):
                    skipped += 1
                    continue

                states = [r["state"] for r in window]
                target_action = window[-1]["action"]

                if any(len(s) != STATE_DIM for s in states):
                    skipped += 1
                    continue

                if len(target_action) != ACTION_DIM:
                    skipped += 1
                    continue

                out.write(json.dumps({
                    "source_json": source_json,
                    "source_rpl": window[-1]["source_rpl"],
                    "fightname": window[-1]["fightname"],
                    "mod": window[-1]["mod"],
                    "start_frame": window[0]["frame"],
                    "end_frame": window[-1]["frame"],
                    "seq_len": SEQ_LEN,
                    "states": states,
                    "action": target_action,
                }, ensure_ascii=False) + "\n")

                total_sequences += 1

    summary = {
        "input": str(IN_DATASET),
        "output": str(OUT_DATASET),
        "seq_len": SEQ_LEN,
        "state_dim": STATE_DIM,
        "action_dim": ACTION_DIM,
        "replays": len(rows_by_replay),
        "sequences": total_sequences,
        "skipped": skipped,
    }

    SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("Dataset séquentiel:", OUT_DATASET)
    print("Résumé:", SUMMARY)
    print("Replays:", len(rows_by_replay))
    print("Séquences:", total_sequences)
    print("Skipped:", skipped)


if __name__ == "__main__":
    main()
