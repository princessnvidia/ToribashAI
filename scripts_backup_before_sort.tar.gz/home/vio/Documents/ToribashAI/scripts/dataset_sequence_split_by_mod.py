#!/usr/bin/env python3
from pathlib import Path
import json
import random
from collections import defaultdict, Counter

BASE = Path.home() / "Documents/ToribashAI"

IN_DATASET = BASE / "datasets" / "ml" / "parkour_sequences_len8.jsonl"
OUT_DIR = BASE / "datasets" / "ml"

TRAIN_OUT = OUT_DIR / "parkour_sequences_len8_train_by_mod.jsonl"
VAL_OUT = OUT_DIR / "parkour_sequences_len8_val_by_mod.jsonl"
SUMMARY = OUT_DIR / "parkour_sequences_len8_mod_split_summary.json"

TRAIN_RATIO = 0.9
SEED = 42

random.seed(SEED)


def main():
    rows_by_replay = defaultdict(list)
    replay_mod = {}

    with IN_DATASET.open("r", encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)

            replay = row["source_json"]
            mod = row.get("mod") or "UNKNOWN"

            rows_by_replay[replay].append(row)
            replay_mod[replay] = mod

    replays_by_mod = defaultdict(list)

    for replay, mod in replay_mod.items():
        replays_by_mod[mod].append(replay)

    train_replays = set()
    val_replays = set()

    for mod, replays in replays_by_mod.items():
        replays = sorted(replays)
        random.shuffle(replays)

        if len(replays) == 1:
            train_replays.add(replays[0])
            continue

        val_count = max(1, int(len(replays) * (1.0 - TRAIN_RATIO)))

        val_part = replays[:val_count]
        train_part = replays[val_count:]

        val_replays.update(val_part)
        train_replays.update(train_part)

    train_sequences = 0
    val_sequences = 0

    train_mods = Counter()
    val_mods = Counter()

    with TRAIN_OUT.open("w", encoding="utf-8") as train_f, \
         VAL_OUT.open("w", encoding="utf-8") as val_f:

        for replay in sorted(rows_by_replay.keys()):
            rows = rows_by_replay[replay]
            mod = replay_mod.get(replay, "UNKNOWN")

            if replay in val_replays:
                target = val_f
                val_mods[mod] += len(rows)
            else:
                target = train_f
                train_mods[mod] += len(rows)

            for row in rows:
                target.write(json.dumps(row, ensure_ascii=False) + "\n")

                if replay in val_replays:
                    val_sequences += 1
                else:
                    train_sequences += 1

    summary = {
        "input": str(IN_DATASET),
        "train_output": str(TRAIN_OUT),
        "val_output": str(VAL_OUT),
        "seed": SEED,
        "train_ratio": TRAIN_RATIO,
        "total_replays": len(rows_by_replay),
        "total_mods": len(replays_by_mod),
        "train_replays": len(train_replays),
        "val_replays": len(val_replays),
        "train_sequences": train_sequences,
        "val_sequences": val_sequences,
        "top_train_mods": train_mods.most_common(40),
        "top_val_mods": val_mods.most_common(40),
        "mods_with_single_replay": sum(
            1 for replays in replays_by_mod.values()
            if len(replays) == 1
        ),
    }

    SUMMARY.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )

    print("Train:", TRAIN_OUT)
    print("Val:", VAL_OUT)
    print("Résumé:", SUMMARY)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
